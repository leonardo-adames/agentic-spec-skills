---
name: hig-technologies
description: "Check for .claude/apple-design-context.md before asking questions. Use existing context and only ask for information not already covered."
risk: safe
source: community
date_added: '2026-02-27'
---

# Apple HIG: Technologies

Check for `.claude/apple-design-context.md` before asking questions. Use existing context and only ask for information not already covered.

## Key Principles

### General

1. **Apple technologies extend app capabilities through system integration.** Each technology has established user-facing patterns; deviating creates confusion and erodes trust.

2. **Privacy and user control are paramount.** Especially for health, payment, and identity technologies. Request only needed data, explain why, respect choices.

### Siri and Voice

3. **Natural, predictable, recoverable.** Clear conversational intent phrases that complete quickly and confirm results. Support App Shortcuts for proactive suggestions. Handle errors with clear fallbacks.

### Payments and Commerce

4. **Transparent and frictionless.** Standard Apple Pay button styles. Never ask for card details when Apple Pay is available. Clearly describe what the user is buying, the price, and whether it's one-time or subscription.

### Health and Fitness

5. **Health data is deeply personal.** Explain the health benefit before requesting access. CareKit tasks should be encouraging. ResearchKit consent flows must be thorough, readable, and respect autonomy.

### Smart Home

6. **Simple and reliable.** Immediate response when controlling devices. Clear device state. Graceful handling of connectivity issues.

### Augmented Reality

7. **Genuine value, not gimmicks.** Use AR when spatial context improves understanding. Guide setup (surface, lighting, space). Provide clear exit back to standard interaction.

### Machine Learning and Generative AI

8. **Enhance without surprising.** Smart suggestions, image recognition, text prediction. Clearly attribute AI-generated content. Controls to edit, regenerate, or dismiss. Let users correct mistakes.

### Identity and Authentication

9. **Sign in with Apple as top option.** Standard button styles. Respect email hiding preference. ID Verifier: guided flows, don't store sensitive data beyond what verification requires.

### Cloud and Data

10. **Invisible and reliable sync.** Data appears on all devices without manual intervention. Handle conflicts gracefully. Never lose data.

### Shared Experiences

11. **Real-time participation.** SharePlay: support multiple participants, show presence, handle latency. AirPlay: appropriate Now Playing metadata.

### Automotive

12. **Driver safety first.** Minimize interaction complexity, large touch targets, no distracting content. Only permitted app types: audio, messaging, EV charging, navigation, parking, quick food ordering.

### Accessibility

13. **Baseline requirement.** Every element has a meaningful VoiceOver label, trait, and action. Support Dynamic Type, Switch Control, and other assistive technologies. Test entirely with VoiceOver enabled.

## Reference Index

| Reference | Topic | Key content |
|---|---|---|
| [siri.md](references/siri.md) | Siri | Intents, shortcuts, voice interaction, App Shortcuts |
| [apple-pay.md](references/apple-pay.md) | Apple Pay | Payment buttons, checkout flow, security |
| [tap-to-pay-on-iphone.md](references/tap-to-pay-on-iphone.md) | Tap to Pay | Merchant flows, contactless payment |
| [in-app-purchase.md](references/in-app-purchase.md) | In-app purchase | Subscriptions, one-time purchases, transparency |
| [healthkit.md](references/healthkit.md) | HealthKit | Health data access, privacy, permissions |
| [carekit.md](references/carekit.md) | CareKit | Care plans, tasks, health management |
| [researchkit.md](references/researchkit.md) | ResearchKit | Studies, informed consent, data collection |
| [homekit.md](references/homekit.md) | HomeKit | Smart home control, device state, scenes |
| [augmented-reality.md](references/augmented-reality.md) | ARKit | Spatial context, surface detection, setup |
| [machine-learning.md](references/machine-learning.md) | Core ML | Predictions, smart features, confidence handling |
| [generative-ai.md](references/generative-ai.md) | Generative AI | Attribution, editing, responsible AI, uncertainty |
| [icloud.md](references/icloud.md) | iCloud | CloudKit, cross-device sync, conflict resolution |
| [sign-in-with-apple.md](references/sign-in-with-apple.md) | Sign in with Apple | Authentication, privacy, button styles |
| [id-verifier.md](references/id-verifier.md) | ID Verifier | Identity verification, document scanning |
| [shareplay.md](references/shareplay.md) | SharePlay | Shared experiences, participant presence |
| [airplay.md](references/airplay.md) | AirPlay | Media streaming, Now Playing, wireless display |
| [carplay.md](references/carplay.md) | CarPlay | Driver safety, permitted app types, large targets |
| [game-center.md](references/game-center.md) | Game Center | Achievements, leaderboards, multiplayer |
| [voiceover.md](references/voiceover.md) | VoiceOver | Screen reader, labels, traits, accessibility |
| [wallet.md](references/wallet.md) | Wallet | Passes, tickets, loyalty cards |
| [nfc.md](references/nfc.md) | NFC | Tag reading, quick interactions, App Clips |
| [maps.md](references/maps.md) | Maps | Location display, annotations, directions |
| [mac-catalyst.md](references/mac-catalyst.md) | Mac Catalyst | iPad to Mac, menu bar, keyboard, pointer |
| [live-photos.md](references/live-photos.md) | Live Photos | Motion capture, playback, editing |
| [imessage-apps-and-stickers.md](references/imessage-apps-and-stickers.md) | iMessage apps | Messages extension, stickers, compact UI |
| [shazamkit.md](references/shazamkit.md) | ShazamKit | Audio recognition, music identification |
| [always-on.md](references/always-on.md) | Always-on display | Dimmed state, power efficiency, reduced updates |
| [photo-editing.md](references/photo-editing.md) | Photo editing | System photo editor, filters, adjustments |

## Output Format

1. **Implementation checklist** -- step-by-step requirements per Apple's guidelines.
2. **Required vs optional features** for approval.
3. **Privacy and permission requirements** -- data access, usage descriptions.
4. **User-facing flow** from permission prompt through task completion.
5. **Testing guidance** -- key scenarios including edge cases.

## Questions to Ask

1. Which Apple technology?
2. Core use case?
3. Which platforms?
4. API requirements and entitlements reviewed?
5. What data or permissions needed?

## Related Skills

- **hig-inputs** -- Input methods interacting with technologies (voice for Siri, Pencil for AR, gestures for Maps)
- **hig-components-system** -- Widgets, complications, Live Activities surfacing technology data
- **hig-components-status** -- Progress indicators for technology operations (sync, payment, AR loading)

---

*Built by [Raintree Technology](https://raintree.technology) · [More developer tools](https://raintree.technology)*

## When to Use
This skill is applicable to execute the workflow or actions described in the overview.

## Limitations
- Use this skill only when the task clearly matches the scope described above.
- Do not treat the output as a substitute for environment-specific validation, testing, or expert review.
- Stop and ask for clarification if required inputs, permissions, safety boundaries, or success criteria are missing.
